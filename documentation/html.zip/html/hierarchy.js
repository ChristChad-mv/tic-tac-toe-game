var hierarchy =
[
    [ "Enum", null, [
      [ "color.TColor", "classcolor_1_1_t_color.html", null ]
    ] ],
    [ "game_logic.GameLogic", "classgame__logic_1_1_game_logic.html", null ],
    [ "gui.TicTacToeGUI", "classgui_1_1_tic_tac_toe_g_u_i.html", null ],
    [ "player.TPlayer", "classplayer_1_1_t_player.html", null ],
    [ "TPlayer", null, [
      [ "PlayerHumain.TPlayerHumain", "class_player_humain_1_1_t_player_humain.html", null ],
      [ "PlayerIA.TPlayerIA", "class_player_i_a_1_1_t_player_i_a.html", null ]
    ] ]
];