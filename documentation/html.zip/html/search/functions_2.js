var searchData=
[
  ['plrget_5fcolor_0',['PLRget_color',['../classplayer_1_1_t_player.html#a97b0e45a982efd4cd84b7637f012cd41',1,'player::TPlayer']]],
  ['plrget_5fname_1',['PLRget_name',['../classplayer_1_1_t_player.html#ad15934e9af3522a27fa7baffeafacd68',1,'player::TPlayer']]],
  ['plrget_5fpossible_5fmoves_2',['PLRget_possible_moves',['../class_player_i_a_1_1_t_player_i_a.html#af553a680caa9cd72a8a7e26031d81fed',1,'PlayerIA::TPlayerIA']]],
  ['plris_5fai_3',['PLRis_ai',['../classplayer_1_1_t_player.html#ab703a24dd329ef45092cf44581929cfe',1,'player::TPlayer']]],
  ['plrjouer_4',['PLRjouer',['../classplayer_1_1_t_player.html#a745124ec5b4cbbe7b2762a1deb8845cd',1,'player.TPlayer.PLRjouer()'],['../class_player_humain_1_1_t_player_humain.html#a917a43f998fe5304a34cad2713a2dcec',1,'PlayerHumain.TPlayerHumain.PLRjouer()'],['../class_player_i_a_1_1_t_player_i_a.html#a8830bb57fe960c0b2a5398e0535ab591',1,'PlayerIA.TPlayerIA.PLRjouer(self, GameLogic game)']]],
  ['plrminimax_5',['PLRminimax',['../class_player_i_a_1_1_t_player_i_a.html#a301000a12f483886f5562452b5edc57c',1,'PlayerIA::TPlayerIA']]],
  ['plrrecord_5fmove_6',['PLRrecord_move',['../class_player_humain_1_1_t_player_humain.html#ae83af36f7f7fd6842921e4159791c5cb',1,'PlayerHumain::TPlayerHumain']]],
  ['plrset_5fai_7',['PLRset_ai',['../classplayer_1_1_t_player.html#a2a6c26d2d5d380ce49e9b6a039f428b5',1,'player::TPlayer']]],
  ['plrset_5fcolor_8',['PLRset_color',['../classplayer_1_1_t_player.html#ab66317fd2987bb27f3203d06577cba4d',1,'player::TPlayer']]],
  ['plrset_5fname_9',['PLRset_name',['../classplayer_1_1_t_player.html#aa33effce6a3c668689b056ceebace8eb',1,'player::TPlayer']]],
  ['plrsimulate_5fmove_10',['PLRsimulate_move',['../class_player_i_a_1_1_t_player_i_a.html#a7830288ef2c7aa97701653327ed3a48a',1,'PlayerIA::TPlayerIA']]],
  ['plrundo_5flast_5fmove_11',['PLRundo_last_move',['../class_player_humain_1_1_t_player_humain.html#a8fc88bca0c22678d345162a87f6bc31b',1,'PlayerHumain::TPlayerHumain']]]
];
