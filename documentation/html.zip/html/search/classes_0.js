var searchData=
[
  ['gamelogic_0',['GameLogic',['../classgame__logic_1_1_game_logic.html',1,'game_logic']]]
];
