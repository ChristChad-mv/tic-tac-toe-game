var searchData=
[
  ['tkinter_5fcolor_0',['tkinter_color',['../classcolor_1_1_t_color.html#ad09b58a24a0f545834b42bdd8986a847',1,'color::TColor']]]
];
