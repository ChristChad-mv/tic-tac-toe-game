var classplayer_1_1_t_player =
[
    [ "__init__", "classplayer_1_1_t_player.html#abbec5a1dbdebffc91e3ad7c391c2d5cb", null ],
    [ "PLRget_color", "classplayer_1_1_t_player.html#a97b0e45a982efd4cd84b7637f012cd41", null ],
    [ "PLRget_name", "classplayer_1_1_t_player.html#ad15934e9af3522a27fa7baffeafacd68", null ],
    [ "PLRis_ai", "classplayer_1_1_t_player.html#ab703a24dd329ef45092cf44581929cfe", null ],
    [ "PLRjouer", "classplayer_1_1_t_player.html#a745124ec5b4cbbe7b2762a1deb8845cd", null ],
    [ "PLRset_ai", "classplayer_1_1_t_player.html#a2a6c26d2d5d380ce49e9b6a039f428b5", null ],
    [ "PLRset_color", "classplayer_1_1_t_player.html#ab66317fd2987bb27f3203d06577cba4d", null ],
    [ "PLRset_name", "classplayer_1_1_t_player.html#aa33effce6a3c668689b056ceebace8eb", null ]
];