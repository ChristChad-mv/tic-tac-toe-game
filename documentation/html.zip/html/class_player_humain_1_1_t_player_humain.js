var class_player_humain_1_1_t_player_humain =
[
    [ "__init__", "class_player_humain_1_1_t_player_humain.html#a2c86263944abbf305ab546ead947f4ef", null ],
    [ "PLRjouer", "class_player_humain_1_1_t_player_humain.html#a917a43f998fe5304a34cad2713a2dcec", null ],
    [ "PLRrecord_move", "class_player_humain_1_1_t_player_humain.html#ae83af36f7f7fd6842921e4159791c5cb", null ],
    [ "PLRundo_last_move", "class_player_humain_1_1_t_player_humain.html#a8fc88bca0c22678d345162a87f6bc31b", null ]
];