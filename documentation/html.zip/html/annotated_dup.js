var annotated_dup =
[
    [ "color", null, [
      [ "TColor", "classcolor_1_1_t_color.html", "classcolor_1_1_t_color" ]
    ] ],
    [ "game_logic", null, [
      [ "GameLogic", "classgame__logic_1_1_game_logic.html", "classgame__logic_1_1_game_logic" ]
    ] ],
    [ "gui", null, [
      [ "TicTacToeGUI", "classgui_1_1_tic_tac_toe_g_u_i.html", "classgui_1_1_tic_tac_toe_g_u_i" ]
    ] ],
    [ "player", null, [
      [ "TPlayer", "classplayer_1_1_t_player.html", "classplayer_1_1_t_player" ]
    ] ],
    [ "PlayerHumain", null, [
      [ "TPlayerHumain", "class_player_humain_1_1_t_player_humain.html", "class_player_humain_1_1_t_player_humain" ]
    ] ],
    [ "PlayerIA", null, [
      [ "TPlayerIA", "class_player_i_a_1_1_t_player_i_a.html", "class_player_i_a_1_1_t_player_i_a" ]
    ] ]
];