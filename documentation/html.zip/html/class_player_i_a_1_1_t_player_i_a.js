var class_player_i_a_1_1_t_player_i_a =
[
    [ "__init__", "class_player_i_a_1_1_t_player_i_a.html#a22883ea9f169d41e27e90761c5817b24", null ],
    [ "PLRget_possible_moves", "class_player_i_a_1_1_t_player_i_a.html#af553a680caa9cd72a8a7e26031d81fed", null ],
    [ "PLRjouer", "class_player_i_a_1_1_t_player_i_a.html#a8830bb57fe960c0b2a5398e0535ab591", null ],
    [ "PLRminimax", "class_player_i_a_1_1_t_player_i_a.html#a301000a12f483886f5562452b5edc57c", null ],
    [ "PLRsimulate_move", "class_player_i_a_1_1_t_player_i_a.html#a7830288ef2c7aa97701653327ed3a48a", null ]
];